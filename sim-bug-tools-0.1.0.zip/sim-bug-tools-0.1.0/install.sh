python3.9 -m build
# python3.9 -m pip install --upgrade --force-reinstall dist/sim_bug_tools_gossq-0.0.1-py3-none-any.whl
python3.9 -m pip install --upgrade --no-deps --force-reinstall dist/sim_bug_tools_gossq-0.0.1-py3-none-any.whl